Credenciais:
cliente1 - passcliente1
cliente2 - passcliente2
cliente3 - passcliente3


Vamos adicionar um novo cliente na base de dados