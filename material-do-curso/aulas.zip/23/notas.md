Vamos buscar um cliente pelo seu id
