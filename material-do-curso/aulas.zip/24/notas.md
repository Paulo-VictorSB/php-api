Vamos buscar um cliente por:
- cidade
- domínio de email
- total homens e mulheres

