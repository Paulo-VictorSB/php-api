<?php

// return the current status of the API

require_once('../_inc/init.php');

$res->set_status('success');
$res->response();