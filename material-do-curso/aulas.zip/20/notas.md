Vamos criar o script init.php dentro do config.
Vamos criar a pasta api_status e o script index.php dentro dela.
