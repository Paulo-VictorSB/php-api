Vamos criar o ficheiro Helper.php dentro da pasta _inc
Vamos importar para o init.php
Vamos criar a função check_request_method()

Vamos criar um endpoint que vai buscar os dados de todos os clientes.
pasta get_all_clients

NOTA: 
vamos adicionar à classe response a possibilidade de ter campos adicionais
set_aditional_field()
