O valor integration_key vai ser um valor que o request vai poder enviar
e que, se existir no request, vamos poder devolver.

A ideia é que o request possa vir acompanhado de informação que seja importante
entregar quando a resposta è devolvida ao cliente.

- vamos colocar essa lógica no api_status
- vamos colocar essa lógica no get_all_clients