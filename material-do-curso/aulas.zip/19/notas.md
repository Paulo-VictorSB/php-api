Vamos começar por criar a estrutura base da API.

1. criar a pasta api
2. criar a pasta _inc
3. colocar lá dentro a biblioteca Database sem o namespace sys4soft
4. criar o script config.php e o seu conteúdo.
5. criar o script Response.php e respetivo conteúdo.

