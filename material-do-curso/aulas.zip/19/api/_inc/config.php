<?php

define('API_VERSION',           'v1.0.0');

// api enabled or disabled
define('API_ACTIVE',            true);
define('API_MESSAGE',           '');

// mysql config
define('MYSQL_HOST',            'localhost');
define('MYSQL_DATABASE',        'udemy_clientes');
define('MYSQL_USER',            'user_udemy_clientes');
define('MYSQL_PASS',            'wic1pOg78OHOVO3Az5zu4E1eLIzEVI');