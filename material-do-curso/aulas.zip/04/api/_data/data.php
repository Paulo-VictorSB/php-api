<?php

return [
    'cão',
    'gato',
    'papagaio',
    'tartaruga',
    'camaleão',
    'coelho',
    'galinha',
    'raposa',
    'pato',
    'cavalo',
];